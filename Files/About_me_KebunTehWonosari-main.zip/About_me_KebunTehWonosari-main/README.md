
## <p align="center"><b>Kelompok 4</b></p>

<div align="center">
  
   <img src="https://github.com/Erlangga-stonks/About_me_KebunTehWonosari/blob/main/photos/er.png" width="150px">
  <img src="https://github.com/Erlangga-stonks/About_me_KebunTehWonosari/blob/main/photos/tya.png" width="150px">
  <img src="https://github.com/Erlangga-stonks/About_me_KebunTehWonosari/blob/main/photos/rama.png" width="150px">
  <img src="https://github.com/Erlangga-stonks/About_me_KebunTehWonosari/blob/main/photos/putri.png" width="150px">
  <img src="https://github.com/Erlangga-stonks/About_me_KebunTehWonosari/blob/main/photos/rhemzy.png" width="150px">
</div>  


  <tr>
    <th float="left" width="100px">&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;Erlangga Rizal M. &ensp;&ensp;&ensp;&ensp; Chintya Puja &ensp;&ensp;&ensp;&ensp;&ensp; Ramadhani AA. &ensp;&ensp;&ensp;&ensp;&ensp; Baiq Mukkaromah &ensp;&ensp;&ensp; Rhemzy Putra M.</th>
  </tr>

  
  #
  
  ## Language of Website <img src="https://i.pinimg.com/originals/b5/01/3d/b5013de0baec1cb12e8e6975fa7b5eb2.gif" width="100px">
  <div align="center">
  <img src="https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white">
  <img src="https://img.shields.io/badge/HTML-239120?style=for-the-badge&logo=html5&logoColor=white">
  <img src="https://img.shields.io/badge/CSS-239120?&style=for-the-badge&logo=css3&logoColor=white">
  <img src="https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black">
 
  #
  
  <div align="center">
  <img src="https://github-readme-stats.vercel.app/api/top-langs/?username=Erlangga-stonks&theme=blue-green">
  </div>
 
  #
  
  ## 📑Paper
  
  Pada Paper Website Kami dapat di akses pada link https://github.com/Erlangga-stonks/About_me_KebunTehWonosari/blob/main/Files/Project.docx
  
